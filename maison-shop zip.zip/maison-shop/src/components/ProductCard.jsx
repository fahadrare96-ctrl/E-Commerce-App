/**
 * components/ProductCard.jsx
 * ─────────────────────────────────────────────────────────────
 * Renders a single product card.
 * Props:
 *   product   – product row from DB
 *   liked     – boolean
 *   onAdd     – () => void
 *   onWish    – () => void
 *   adding    – boolean (shows spinner on add button)
 * ─────────────────────────────────────────────────────────────
 */

export default function ProductCard({ product, liked, onAdd, onWish, adding }) {
  const { name, category, price, old_price, rating, badge, emoji, stock } = product;

  const badgeStyle = {
    New:  { background: '#1a1a1a', color: '#fff' },
    Sale: { background: '#e24b4a', color: '#fff' },
    Top:  { background: '#3b6d11', color: '#fff' },
  }[badge] || {};

  const stars = '★'.repeat(rating) + '☆'.repeat(5 - rating);
  const lowStock = stock <= 8;

  return `
    <article class="card" data-id="${product.id}">
      <div class="card-img">
        ${badge ? `<span class="badge" style="background:${badgeStyle.background};color:${badgeStyle.color}">${badge}</span>` : ''}
        <button class="wish-btn ${liked ? 'liked' : ''}" data-wish="${product.id}" aria-label="Toggle wishlist">
          ${liked ? '♥' : '♡'}
        </button>
        <span class="emoji" aria-hidden="true">${emoji}</span>
        ${lowStock ? `<span class="low-stock">Only ${stock} left</span>` : ''}
      </div>
      <div class="card-body">
        <p class="card-cat">${category}</p>
        <p class="card-name">${name}</p>
        <div class="card-footer">
          <div>
            <div class="price-wrap">
              <span class="price">€${price}</span>
              ${old_price ? `<span class="price-old">€${old_price}</span>` : ''}
            </div>
            <span class="stars" aria-label="${rating} out of 5 stars">${stars}</span>
          </div>
          <button class="add-btn ${adding ? 'loading' : ''}" data-add="${product.id}" aria-label="Add to cart">
            ${adding ? '<span class="btn-spinner"></span>' : '+'}
          </button>
        </div>
      </div>
    </article>`;
}
