/**
 * hooks/useProducts.js
 * ─────────────────────────────────────────────────────────────
 * Custom React hooks that wrap the DB layer.
 * Each hook returns { data, loading, error, refetch }.
 *
 * This is the same pattern used in React Query / SWR —
 * components never touch the DB directly.
 * ─────────────────────────────────────────────────────────────
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import {
  getProducts,
  getCategories,
  getCart,
  addToCart,
  removeFromCart,
  getWishlist,
  toggleWishlist,
} from '../database/db.js';

// ── Generic data-fetching hook ────────────────────────────────
function useQuery(queryFn, deps = []) {
  const [state, setState] = useState({ data: null, loading: true, error: null });
  const mountedRef = useRef(true);

  const run = useCallback(async () => {
    setState(s => ({ ...s, loading: true, error: null }));
    try {
      const data = await queryFn();
      if (mountedRef.current) setState({ data, loading: false, error: null });
    } catch (err) {
      if (mountedRef.current) setState({ data: null, loading: false, error: err.message });
    }
  }, deps); // eslint-disable-line

  useEffect(() => {
    mountedRef.current = true;
    run();
    return () => { mountedRef.current = false; };
  }, [run]);

  return { ...state, refetch: run };
}

// ── Products ──────────────────────────────────────────────────

/** Fetch products, re-fetches when `category` changes */
export function useProducts(category) {
  return useQuery(() => getProducts(category), [category]);
}

/** Fetch all available category names */
export function useCategories() {
  return useQuery(() => getCategories(), []);
}

// ── Cart ──────────────────────────────────────────────────────

export function useCart() {
  const [cartCount, setCartCount] = useState(0);
  const [adding, setAdding]       = useState(null); // product id being added

  // Load initial count from DB
  useEffect(() => {
    getCart().then(items => {
      setCartCount(items.reduce((s, i) => s + i.qty, 0));
    }).catch(() => {});
  }, []);

  const add = useCallback(async (productId) => {
    setAdding(productId);
    try {
      const newCount = await addToCart(productId);
      setCartCount(newCount);
      return true;
    } catch {
      return false;
    } finally {
      setAdding(null);
    }
  }, []);

  const remove = useCallback(async (productId) => {
    try {
      const newCount = await removeFromCart(productId);
      setCartCount(newCount);
    } catch {}
  }, []);

  return { cartCount, adding, addToCart: add, removeFromCart: remove };
}

// ── Wishlist ──────────────────────────────────────────────────

export function useWishlist() {
  const [wishlist, setWishlist] = useState(new Set());

  useEffect(() => {
    getWishlist().then(setWishlist).catch(() => {});
  }, []);

  const toggle = useCallback(async (productId) => {
    const nowLiked = await toggleWishlist(productId);
    setWishlist(prev => {
      const next = new Set(prev);
      nowLiked ? next.add(productId) : next.delete(productId);
      return next;
    });
    return nowLiked;
  }, []);

  return { wishlist, toggleWishlist: toggle };
}
