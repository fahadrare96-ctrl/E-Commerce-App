/**
 * database/db.js
 * ─────────────────────────────────────────────────────────────
 * Local SQLite-style database layer.
 *
 * In a real React Native app this file would use:
 *   import * as SQLite from 'expo-sqlite';
 *   const db = SQLite.openDatabase('maison.db');
 *
 * Here we faithfully mirror that API using localStorage so the
 * entire app logic (hooks, screens, components) stays identical
 * and can be dropped into a native project with zero changes
 * beyond this single file.
 * ─────────────────────────────────────────────────────────────
 */

const DB_VERSION = 2;
const STORE_KEY   = `maison_db_v${DB_VERSION}`;

// ─── Schema ────────────────────────────────────────────────────
const SEED_PRODUCTS = [
  { id:1,  name:'Wireless Noise-Cancelling Headphones', category:'Electronics', price:249, old_price:329, rating:5, badge:'Top',  stock:14, emoji:'🎧', description:'Studio-quality sound with 40-hour battery life and adaptive ANC.' },
  { id:2,  name:'Minimal Leather Tote Bag',             category:'Fashion',     price:189, old_price:null,rating:4, badge:'New',  stock:6,  emoji:'👜', description:'Full-grain vegetable-tanned leather. Fits a 15" laptop.' },
  { id:3,  name:'Ceramic Pour-Over Coffee Set',         category:'Home',        price:74,  old_price:95,  rating:5, badge:'Sale', stock:22, emoji:'☕', description:'Handcrafted matte ceramic dripper with matching carafe.' },
  { id:4,  name:'Smart Watch Series 9',                 category:'Electronics', price:399, old_price:null,rating:5, badge:'New',  stock:9,  emoji:'⌚', description:'Always-on OLED display, ECG, blood oxygen, GPS.' },
  { id:5,  name:'Linen Oversized Blazer',               category:'Fashion',     price:145, old_price:210, rating:4, badge:'Sale', stock:11, emoji:'🧥', description:'Relaxed Italian linen, unstructured silhouette, two patch pockets.' },
  { id:6,  name:'Vitamin C Brightening Serum',          category:'Beauty',      price:58,  old_price:null,rating:5, badge:'Top',  stock:38, emoji:'✨', description:'15% L-ascorbic acid with ferulic acid. Dermatologist tested.' },
  { id:7,  name:'Mechanical Keyboard TKL',              category:'Electronics', price:129, old_price:159, rating:4, badge:null,   stock:17, emoji:'⌨️', description:'Cherry MX Red switches, aluminium top plate, USB-C.' },
  { id:8,  name:'Scented Soy Candle Set × 3',          category:'Home',        price:46,  old_price:null,rating:4, badge:'New',  stock:30, emoji:'🕯️', description:'Cedar, amber & vanilla. 45-hour burn time each.' },
  { id:9,  name:'Retinol Night Recovery Cream',         category:'Beauty',      price:72,  old_price:89,  rating:5, badge:'Sale', stock:25, emoji:'🌙', description:'0.3% encapsulated retinol with ceramides. Fragrance-free.' },
  { id:10, name:'Slim Titanium Card Wallet',            category:'Fashion',     price:95,  old_price:null,rating:4, badge:'New',  stock:40, emoji:'💳', description:'Grade 5 titanium. Holds 12 cards. RFID blocking.' },
  { id:11, name:'Portable Bluetooth Speaker',           category:'Electronics', price:99,  old_price:139, rating:4, badge:'Sale', stock:8,  emoji:'🔊', description:'360° surround sound, IP67 waterproof, 24-hour playback.' },
  { id:12, name:'Handwoven Merino Throw Blanket',       category:'Home',        price:88,  old_price:null,rating:5, badge:'Top',  stock:15, emoji:'🧣', description:'100% Merino wool, 130×180 cm, machine washable.' },
];

// ─── Internal helpers ─────────────────────────────────────────
function _read() {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function _write(data) {
  localStorage.setItem(STORE_KEY, JSON.stringify(data));
}

function _ensureDB() {
  const existing = _read();
  if (!existing) {
    _write({
      products:   SEED_PRODUCTS,
      cart:       [],
      wishlist:   [],
      created_at: Date.now(),
    });
  }
  return _read();
}

// ─── Public API (mirrors expo-sqlite promise API) ──────────────

/**
 * Simulate async DB query with realistic latency.
 * Pass `forceError: true` to test error-handling paths.
 */
function _query(fn, { latency = [600, 1100], errorRate = 0 } = {}) {
  return new Promise((resolve, reject) => {
    const delay = latency[0] + Math.random() * (latency[1] - latency[0]);
    setTimeout(() => {
      if (Math.random() < errorRate) {
        reject(new Error('DB_ERROR: Connection to local database failed.'));
        return;
      }
      try {
        resolve(fn(_ensureDB()));
      } catch (e) {
        reject(e);
      }
    }, delay);
  });
}

// ── Products ──────────────────────────────────────────────────

/** SELECT * FROM products [WHERE category = ?] */
export function getProducts(category = 'All') {
  return _query(db => {
    return category === 'All'
      ? db.products
      : db.products.filter(p => p.category === category);
  }, { errorRate: 0.04 });
}

/** SELECT * FROM products WHERE id = ? */
export function getProductById(id) {
  return _query(db => db.products.find(p => p.id === id) ?? null, { latency:[200,400] });
}

/** SELECT DISTINCT category FROM products */
export function getCategories() {
  return _query(db => {
    const cats = [...new Set(db.products.map(p => p.category))];
    return ['All', ...cats];
  }, { latency:[100,200] });
}

// ── Cart ──────────────────────────────────────────────────────

/** SELECT * FROM cart JOIN products ON … */
export function getCart() {
  return _query(db => {
    return db.cart.map(item => {
      const product = db.products.find(p => p.id === item.product_id);
      return { ...item, product };
    });
  }, { latency:[100,250] });
}

/** INSERT INTO cart / UPDATE cart SET qty = qty + 1 */
export function addToCart(productId) {
  return _query(db => {
    const existing = db.cart.find(c => c.product_id === productId);
    if (existing) {
      existing.qty += 1;
    } else {
      db.cart.push({ product_id: productId, qty: 1, added_at: Date.now() });
    }
    _write(db);
    return db.cart.reduce((s, c) => s + c.qty, 0); // return new total count
  }, { latency:[80,150] });
}

/** DELETE FROM cart WHERE product_id = ? */
export function removeFromCart(productId) {
  return _query(db => {
    db.cart = db.cart.filter(c => c.product_id !== productId);
    _write(db);
    return db.cart.reduce((s, c) => s + c.qty, 0);
  }, { latency:[80,150] });
}

// ── Wishlist ──────────────────────────────────────────────────

/** SELECT product_id FROM wishlist */
export function getWishlist() {
  return _query(db => new Set(db.wishlist.map(w => w.product_id)), { latency:[100,200] });
}

/** INSERT / DELETE wishlist toggle */
export function toggleWishlist(productId) {
  return _query(db => {
    const idx = db.wishlist.findIndex(w => w.product_id === productId);
    if (idx >= 0) {
      db.wishlist.splice(idx, 1);
    } else {
      db.wishlist.push({ product_id: productId, saved_at: Date.now() });
    }
    _write(db);
    return idx < 0; // true = now in wishlist
  }, { latency:[80,150] });
}

// ── Dev utility ───────────────────────────────────────────────
export function resetDatabase() {
  localStorage.removeItem(STORE_KEY);
  _ensureDB();
}
