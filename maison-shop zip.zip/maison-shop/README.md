# Maison — E-Commerce Product Listing App
### Complete Step-by-Step Build Guide

---

## Project Structure

```
maison-shop/
│
├── index.html                  ← Main app (open this in browser)
│
└── src/
    ├── database/
    │   └── db.js               ← Database layer (SQLite API mirror)
    │
    ├── hooks/
    │   └── useProducts.js      ← React custom hooks (loading/error/data)
    │
    └── components/
        └── ProductCard.jsx     ← Product card component
```

---

## Step-by-Step Walkthrough

### STEP 1 — Database Layer (`src/database/db.js`)

This file is the heart of the app. It mirrors the **expo-sqlite** API exactly.

**Key functions:**
| Function | SQL Equivalent |
|---|---|
| `getProducts(category)` | `SELECT * FROM products WHERE category=?` |
| `getCategories()` | `SELECT DISTINCT category FROM products` |
| `addToCart(productId)` | `INSERT INTO cart / UPDATE SET qty=qty+1` |
| `removeFromCart(productId)` | `DELETE FROM cart WHERE product_id=?` |
| `toggleWishlist(productId)` | `INSERT / DELETE FROM wishlist` |

**To switch to real SQLite (React Native):**
```js
// Replace the _query() function body with:
import * as SQLite from 'expo-sqlite';
const db = SQLite.openDatabase('maison.db');

db.transaction(tx => {
  tx.executeSql(
    'SELECT * FROM products WHERE category = ?',
    [category],
    (_, { rows }) => resolve(rows._array),
    (_, error) => reject(error)
  );
});
```
Everything else in the app stays 100% identical.

---

### STEP 2 — Custom Hooks (`src/hooks/useProducts.js`)

Each hook returns `{ data, loading, error, refetch }`.

```js
// Usage in a React component:
const { data: products, loading, error, refetch } = useProducts('Electronics');

if (loading) return <Spinner />;
if (error)   return <ErrorState message={error} onRetry={refetch} />;
return <ProductGrid products={products} />;
```

The `useQuery` base hook handles:
- Setting loading = true before fetch
- Catching errors and storing the message
- Checking `mountedRef` to prevent state updates on unmounted components

---

### STEP 3 — Loading State

**Skeleton Cards** (better than a plain spinner):
- 8 shimmer placeholder cards animate while data loads
- Uses CSS `background-size: 200%` + `animation` for the sweep effect
- Matches the real card layout so the UI doesn't "jump"

**Spinner** on the Add button:
- While `addingId === product.id`, the + button shows a CSS spinner
- Prevents double-taps

---

### STEP 4 — Error Handling

The app handles **3 error surfaces**:

| Surface | Trigger | Recovery |
|---|---|---|
| Grid error state | DB fetch fails (~4% chance) | "Try again" button calls `loadProducts()` |
| Add-to-cart failure | Network error | Toast message, button resets |
| Cart drawer | Handles empty gracefully | Shows empty state illustration |

Error rate can be adjusted in `db.js`:
```js
dbQuery(fn, { errorRate: 0.04 })  // 4% failure rate for demo
```

---

### STEP 5 — Features Built

| Feature | Implementation |
|---|---|
| Product grid | CSS `auto-fill` responsive grid |
| Category filters | Chips re-fetch from DB on click |
| Search | Client-side filter with 200ms debounce |
| Sort | Price asc/desc, top rated — client-side |
| Skeleton loading | 8-card shimmer animation |
| Error + retry | Full error state with retry button |
| Add to cart | Async DB write, badge counter, bump animation |
| Wishlist toggle | Persistent in localStorage DB |
| Product detail | Modal with description, opens on card click |
| Cart drawer | Slide-in drawer with live DB data |
| Toast notifications | Stacked, auto-dismiss after 2.7s |
| Keyboard shortcuts | Esc = close modal/drawer, Cmd+K = search |
| Low stock warning | Shows "Only N left" badge when stock ≤ 8 |
| Responsive | Mobile-first, 2-column on small screens |

---

## How to Run

Simply open `index.html` in any modern browser. No build step needed.

```bash
# Option 1: just open it
open index.html

# Option 2: local server (recommended)
npx serve .
# or
python3 -m http.server 8080
```

---

## Migrating to React Native

1. Copy `src/database/db.js` and replace `localStorage` calls with `expo-sqlite`
2. Copy `src/hooks/useProducts.js` — works as-is with React Native
3. Rebuild the UI using React Native components (`FlatList`, `View`, `Text`, etc.)
4. The data layer and hooks require **zero changes**

---

## Tech Choices Explained

**Why localStorage instead of IndexedDB?**
- Simpler synchronous-style API that mirrors SQLite
- `JSON.parse/stringify` gives us table-like structure
- Trivially swappable for real SQLite

**Why no build tool?**
- Zero dependencies = instant setup for learning
- Everything works by opening one HTML file
- Production app would use Vite/Metro bundler
